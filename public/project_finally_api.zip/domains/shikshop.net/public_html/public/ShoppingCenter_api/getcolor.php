<?php
include 'DatabaseManager.php';


$databaseManager=new DatabaseManager();
$databaseManager->getcolor();