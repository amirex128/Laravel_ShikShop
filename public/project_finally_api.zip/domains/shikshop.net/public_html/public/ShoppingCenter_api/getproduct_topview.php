<?php
include 'DatabaseManager.php';


$databaseManager=new DatabaseManager();
$databaseManager->getproduct_topview(20);
