<?php
include 'DatabaseManager.php';


$databaseManager=new DatabaseManager();
$databaseManager->getproduct_lastproduct(500);
