<?php
include 'DatabaseManager.php';


$databaseManager=new DatabaseManager();
$databaseManager->getproduct_special(20);
